import React, { useState, useEffect } from "react";
import { StyleSheet, View, Text } from "react-native";

import MQTTService from './src/services/mqttService';
import StorageService from './src/storage/storageService';

import StatusModal from './src/components/StatusModal';
import LightControl from './src/components/LightControl';
import Gauges from './src/components/Gauges';

const mqtt = new MQTTService();

export default function App() {

  const [isConnected, setIsConnected] = useState(false);
  const [showError, setShowError] = useState(false);

  const [isLightOn, setIsLightOn] = useState(false);

  const [temp, setTemp] = useState(0);
  const [hum, setHum] = useState(0);

  const mqttConfig = {
    host: process.env.EXPO_PUBLIC_MQTT_HOST,
    port: 8884,
    path: "/mqtt",
    protocol: "wss",
    user: process.env.EXPO_PUBLIC_MQTT_USER,
    pass: process.env.EXPO_PUBLIC_MQTT_PASS,
    clientId: 'RN_App_' + Math.floor(Math.random() * 10000),
  };

  useEffect(() => {

    loadLocalData();

    startConnection();

    return () => {
      mqtt.disconnect();
    };

  }, []);

  const loadLocalData = async () => {

    const savedLight = await StorageService.getLightState();
    const savedTemp = await StorageService.getTemp();
    const savedHum = await StorageService.getHum();

    setIsLightOn(savedLight);
    setTemp(savedTemp);
    setHum(savedHum);
  };

  const startConnection = () => {

    setShowError(false);

    mqtt.connect(

      mqttConfig,

      async (topic, message) => {

        if (topic === 'casa/temp') {

          const value = parseFloat(message);

          setTemp(value);

          await StorageService.saveTemp(value);
        }

        if (topic === 'casa/umid') {

          const value = parseFloat(message);

          setHum(value);

          await StorageService.saveHum(value);
        }

        if (topic === 'casa/luz') {

          const value = message === "1";

          setIsLightOn(value);

          await StorageService.saveLightState(value);
        }
      },

      () => {

        setIsConnected(true);

        mqtt.subscribe('casa/temp');
        mqtt.subscribe('casa/umid');
        mqtt.subscribe('casa/luz');
      },

      (err) => {

        console.log(err);

        setIsConnected(false);

        setShowError(true);
      }
    );
  };

  const toggleLight = async () => {

    const mqttState = isLightOn ? "0" : "1";

    const localState = !isLightOn;

    setIsLightOn(localState);

    await StorageService.saveLightState(localState);

    mqtt.publish('casa/luz', mqttState);
  };

  return (

    <View style={styles.container}>

      <Text style={styles.header}>
        Smart Home IoT
      </Text>

      <LightControl
        isLightOn={isLightOn}
        onToggle={toggleLight}
      />

      <Gauges
        temp={temp}
        hum={hum}
      />

      <StatusModal
        visible={showError}
        onRetry={startConnection}
        onLater={() => setShowError(false)}
      />

    </View>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#121212',
    padding: 20,
    alignItems: 'center'
  },

  header: {
    color: '#FFF',
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 50,
    marginBottom: 10
  },

  status: {
    color: '#AAA',
    marginBottom: 20
  }
});