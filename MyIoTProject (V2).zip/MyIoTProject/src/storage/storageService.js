import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEYS = {
  LIGHT: '@light_state',
  TEMP: '@temperature',
  HUM: '@humidity',
};

class StorageService {

  async saveLightState(value) {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.LIGHT, JSON.stringify(value));
    } catch (e) {
      console.log('Erro ao salvar luz:', e);
    }
  }

  async getLightState() {
    try {
      const value = await AsyncStorage.getItem(STORAGE_KEYS.LIGHT);
      return value != null ? JSON.parse(value) : false;
    } catch (e) {
      console.log('Erro ao buscar luz:', e);
      return false;
    }
  }

  async saveTemp(value) {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.TEMP, value.toString());
    } catch (e) {
      console.log('Erro ao salvar temp:', e);
    }
  }

  async getTemp() {
    try {
      const value = await AsyncStorage.getItem(STORAGE_KEYS.TEMP);
      return value != null ? parseFloat(value) : 0;
    } catch (e) {
      console.log('Erro ao buscar temp:', e);
      return 0;
    }
  }

  async saveHum(value) {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.HUM, value.toString());
    } catch (e) {
      console.log('Erro ao salvar hum:', e);
    }
  }

  async getHum() {
    try {
      const value = await AsyncStorage.getItem(STORAGE_KEYS.HUM);
      return value != null ? parseFloat(value) : 0;
    } catch (e) {
      console.log('Erro ao buscar hum:', e);
      return 0;
    }
  }
}

export default new StorageService();